// connect-phone-app.js - Handles connect phone app copy order functionality

const ConnectPhoneApp = {
  // Function to check if current URL matches the target URL
  isCorrectURL: () => {
    return (
      window.location.href.includes("https://app.connectphone.gr/orders") ||
      window.location.href.includes("https://app.connectphone.gr/sims")
    );
  },

  // Function to check if current URL is orders page (for copy functionality)
  isOrdersURL: () => {
    return window.location.href.includes("https://app.connectphone.gr/orders");
  },

  // Function to check if current URL is sims page (for product count functionality)
  isSimsURL: () => {
    return window.location.href.includes("https://app.connectphone.gr/sims");
  },

  // Function to get copy icon SVG
  getCopyIconSVG: () => {
    return `
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <rect width="14" height="14" x="8" y="8" rx="2" ry="2"/>
        <path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>
      </svg>
    `;
  },

  // Function to get custom check icon SVG
  getCheckIconSVG: () => {
    return `
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M20 6L9 17l-5-5"/>
      </svg>
    `;
  },

  // Function to create copy order button (modern and subtle styling)
  createCopyOrderButton: () => {
    const button = document.createElement("button");
    button.innerHTML = ConnectPhoneApp.getCopyIconSVG();

    button.style.cssText = `
      background: rgba(108, 117, 125, 0.08);
      border: 1px solid rgba(108, 117, 125, 0.2);
      border-radius: 6px;
      padding: 8px;
      cursor: pointer;
      color: #6c757d;
      transition: all 0.2s ease;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 32px;
      height: 32px;
      vertical-align: middle;
      position: relative;
      overflow: hidden;
    `;

    // Add hover effects
    button.addEventListener("mouseenter", () => {
      if (!button.classList.contains("copying")) {
        button.style.background = "rgba(108, 117, 125, 0.12)";
        button.style.borderColor = "rgba(108, 117, 125, 0.3)";
        button.style.color = "#495057";
        button.style.transform = "translateY(-1px)";
        button.style.boxShadow = "0 2px 4px rgba(0, 0, 0, 0.1)";
      }
    });

    button.addEventListener("mouseleave", () => {
      if (!button.classList.contains("copying")) {
        button.style.background = "rgba(108, 117, 125, 0.08)";
        button.style.borderColor = "rgba(108, 117, 125, 0.2)";
        button.style.color = "#6c757d";
        button.style.transform = "translateY(0)";
        button.style.boxShadow = "none";
      }
    });

    // Add active state
    button.addEventListener("mousedown", () => {
      if (!button.classList.contains("copying")) {
        button.style.transform = "translateY(0)";
        button.style.background = "rgba(108, 117, 125, 0.16)";
      }
    });

    button.addEventListener("mouseup", () => {
      if (!button.classList.contains("copying")) {
        button.style.transform = "translateY(-1px)";
        button.style.background = "rgba(108, 117, 125, 0.12)";
      }
    });

    return button;
  },

  // Function to show copy success feedback
  showCopySuccess: (button) => {
    // Add copying class to prevent hover effects
    button.classList.add("copying");

    // Change to check icon with success styling
    button.innerHTML = ConnectPhoneApp.getCheckIconSVG();
    button.style.background = "rgba(40, 167, 69, 0.1)";
    button.style.borderColor = "rgba(40, 167, 69, 0.3)";
    button.style.color = "#28a745";
    button.style.transform = "translateY(0)";
    button.style.boxShadow = "none";

    // Reset after 1.5 seconds
    setTimeout(() => {
      button.classList.remove("copying");
      button.innerHTML = ConnectPhoneApp.getCopyIconSVG();
      button.style.background = "rgba(108, 117, 125, 0.08)";
      button.style.borderColor = "rgba(108, 117, 125, 0.2)";
      button.style.color = "#6c757d";
    }, 1500);
  },

  // Function to copy text to clipboard
  copyToClipboard: async (text, button) => {
    try {
      if (navigator.clipboard && window.isSecureContext) {
        await navigator.clipboard.writeText(text);
      } else {
        // Fallback for older browsers
        const textArea = document.createElement("textarea");
        textArea.value = text;
        textArea.style.position = "fixed";
        textArea.style.left = "-999999px";
        textArea.style.top = "-999999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        document.execCommand("copy");
        textArea.remove();
      }

      ConnectPhoneApp.showCopySuccess(button);
    } catch (err) {
      console.error("Failed to copy text: ", err);

      // Show error state briefly
      button.style.background = "rgba(220, 53, 69, 0.1)";
      button.style.borderColor = "rgba(220, 53, 69, 0.3)";
      button.style.color = "#dc3545";

      setTimeout(() => {
        button.style.background = "rgba(108, 117, 125, 0.08)";
        button.style.borderColor = "rgba(108, 117, 125, 0.2)";
        button.style.color = "#6c757d";
      }, 1000);
    }
  },

  // Function to add header for copy button column
  addCopyColumnHeader: () => {
    const headerRow = document.querySelector("thead tr");
    if (headerRow && !headerRow.querySelector(".copy-header-cell")) {
      const copyHeaderCell = document.createElement("th");
      copyHeaderCell.className = "copy-header-cell sorting_disabled";
      copyHeaderCell.setAttribute("rowspan", "1");
      copyHeaderCell.setAttribute("colspan", "1");
      copyHeaderCell.setAttribute("aria-label", "Αντιγραφή");
      copyHeaderCell.style.cssText = `
        width: 60px;
        text-align: center;
        font-weight: 500;
        color: #6c757d;
        font-size: 13px;
        padding: 12px 8px;
      `;
      copyHeaderCell.textContent = "Αντιγραφή";
      headerRow.appendChild(copyHeaderCell);
    }
  },

  // Function to replace td 5 content with span count
  replaceProductCount: () => {
    const rows = document.querySelectorAll("tr");

    rows.forEach((row) => {
      const tds = row.querySelectorAll("td");

      // Check if row has at least 5 tds
      if (tds.length >= 5) {
        const td5 = tds[4]; // 5th td (0-indexed, so index 4)
        const spans = td5.querySelectorAll("span");
        const numberOfSpans = spans.length;

        // Replace content with span count
        td5.textContent = `${numberOfSpans} Products`;
      }
    });
  },

  // Function to resize QR code images in td 4 to half size
  resizeQRCodes: () => {
    const rows = document.querySelectorAll("tr");

    rows.forEach((row) => {
      const tds = row.querySelectorAll("td");

      // Check if row has at least 4 tds
      if (tds.length >= 4) {
        const td4 = tds[3]; // 4th td (0-indexed, so index 3)
        const svgs = td4.querySelectorAll("svg");

        svgs.forEach((svg) => {
          // Get current dimensions
          const currentWidth = svg.getAttribute("width") || "150";
          const currentHeight = svg.getAttribute("height") || "150";

          // Calculate half size
          const newWidth = Math.floor(parseInt(currentWidth) / 2);
          const newHeight = Math.floor(parseInt(currentHeight) / 2);

          // Set new dimensions
          svg.setAttribute("width", newWidth.toString());
          svg.setAttribute("height", newHeight.toString());

          // Also update viewBox if it exists to maintain aspect ratio
          const viewBox = svg.getAttribute("viewBox");
          if (viewBox) {
            const viewBoxParts = viewBox.split(" ");
            if (viewBoxParts.length === 4) {
              viewBoxParts[2] = newWidth.toString();
              viewBoxParts[3] = newHeight.toString();
              svg.setAttribute("viewBox", viewBoxParts.join(" "));
            }
          }
        });
      }
    });
  },

  // Function to style select2 rendered elements
  styleSelect2Elements: () => {
    const select2Elements = document.querySelectorAll(
      ".select2-selection__rendered"
    );
    select2Elements.forEach((element) => {
      element.style.cssText = `
        max-height: 100px;
        overflow-y: auto;
      `;
    });
  },

  // Function to process connect phone app copy order
  processConnectPhoneAppCopyOrder: (settings) => {
    if (!settings.connectPhoneAppCopyOrder) return;

    // Check if we're on the correct URL
    if (!ConnectPhoneApp.isCorrectURL()) {
      console.log("Connect phone app tweak: Not on target URL, skipping...");
      return;
    }

    // Apply select2 styling (for both orders and sims)
    ConnectPhoneApp.styleSelect2Elements();

    // Resize QR codes in td 4 to half size (for both orders and sims)
    ConnectPhoneApp.resizeQRCodes();

    // Replace product count in td 5 (sims only)
    if (ConnectPhoneApp.isSimsURL()) {
      ConnectPhoneApp.replaceProductCount();
    }

    // Only add copy functionality for orders URL
    if (!ConnectPhoneApp.isOrdersURL()) {
      console.log(
        "Connect phone app tweak: Not on orders URL, skipping copy functionality..."
      );
      return;
    }

    // Add header for copy button column (orders only)
    ConnectPhoneApp.addCopyColumnHeader();

    const rows = document.querySelectorAll("tr");

    rows.forEach((row) => {
      const tds = row.querySelectorAll("td");

      // Check if row has at least 7 tds and doesn't already have copy order cell
      if (tds.length >= 7 && !row.querySelector(".copy-order-cell")) {
        // Create new td with copy button
        const copyOrderCell = document.createElement("td");
        copyOrderCell.className = "copy-order-cell";
        copyOrderCell.style.cssText = `
          text-align: center;
          padding: 8px;
          vertical-align: middle;
        `;

        const copyOrderButton = ConnectPhoneApp.createCopyOrderButton();

        // Get values from columns 3, 4, 5, 6, 7 (indices 2, 3, 4, 5, 6)
        const values = [];
        for (let i = 2; i <= 6; i++) {
          if (tds[i]) {
            let value = tds[i].textContent.trim();
            // Add "APP " prefix to the value of td 3 (index 2)
            if (i === 2) {
              value = "APP " + value;
            }
            values.push(value);
          }
        }

        const copyText = values.join("\n");
        copyOrderButton.title = `Αντιγραφή στοιχείων παραγγελίας:\n${copyText}`;

        copyOrderButton.addEventListener("click", (e) => {
          e.preventDefault();
          e.stopPropagation();
          ConnectPhoneApp.copyToClipboard(copyText, copyOrderButton);
        });

        copyOrderCell.appendChild(copyOrderButton);
        row.appendChild(copyOrderCell);
      }
    });
  },

  // Function to cleanup connect phone app elements
  cleanup: () => {
    document.querySelectorAll(".copy-order-cell").forEach((el) => el.remove());
    document.querySelectorAll(".copy-header-cell").forEach((el) => el.remove());
  },
};
