// invoice-totals.js - Handles invoice total processing

const InvoiceTotals = {
  // Function to extract numeric value from text
  extractNumericValue: (text) => {
    // Remove currency symbols and non-numeric characters except dots and commas
    const numericString = text.replace(/[^\d.,]/g, "");
    // Handle European number format (comma as decimal separator)
    const normalizedString = numericString.replace(",", ".");
    return parseFloat(normalizedString).toString();
  },

  // Function to create copy button
  createCopyButton: () => {
    const button = document.createElement("button");
    button.textContent = "📋";

    button.style.cssText = `
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border: none;
      border-radius: 8px;
      padding: 8px;
      margin-right: 8px;
      cursor: pointer;
      color: white;
      transition: all 0.3s ease;
      box-shadow: 0 2px 8px rgba(102, 126, 234, 0.3);
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 32px;
      height: 32px;
      vertical-align: middle;
      font-size: 14px;
    `;

    return button;
  },

  // Function to process invoice totals
  processInvoiceTotals: (settings) => {
    if (!settings.processInvoiceTotals) return;

    const invoiceTotalRows = document.querySelectorAll("tr.invoice-total");

    invoiceTotalRows.forEach((row) => {
      const tds = row.querySelectorAll("td");

      if (tds.length >= 3) {
        const thirdTd = tds[2];

        // Check if button already exists
        if (thirdTd.querySelector(".copy-value-btn")) {
          return;
        }

        const valueText = thirdTd.textContent.trim();
        const numericValue = InvoiceTotals.extractNumericValue(valueText);

        if (numericValue && !isNaN(parseFloat(numericValue))) {
          const copyButton = InvoiceTotals.createCopyButton();
          copyButton.className = "copy-value-btn";
          copyButton.title = `Copy numeric value: ${numericValue}`;

          copyButton.addEventListener("click", (e) => {
            e.preventDefault();
            e.stopPropagation();
            Utils.copyToClipboard(numericValue, copyButton);
          });

          // Insert button at the beginning of the td
          thirdTd.insertBefore(copyButton, thirdTd.firstChild);
        }
      }
    });
  },

  // Function to cleanup invoice totals buttons
  cleanup: () => {
    document.querySelectorAll(".copy-value-btn").forEach((el) => el.remove());
  },
};
