// booking-lists.js - Handles booking list processing and API calls

const BookingLists = {
  // Function to extract PRO code numeric part
  extractProCodeNumeric: (text) => {
    // Look for pattern like PRO-XXXXXXXX and extract the numeric part
    const match = text.match(/PRO-(\d+)/);
    return match ? match[1] : null;
  },

  // Function to get current date in required format
  getCurrentDate: () => {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, "0");
    const day = String(now.getDate()).padStart(2, "0");
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
  },

  // Function to convert string to bytes
  stringToBytes: (str) => {
    return new TextEncoder().encode(str);
  },

  // Function to create HMAC SHA1 signature
  createHmacSha1: async (message, secret) => {
    const key = await crypto.subtle.importKey(
      "raw",
      BookingLists.stringToBytes(secret),
      { name: "HMAC", hash: "SHA-1" },
      false,
      ["sign"]
    );

    const signature = await crypto.subtle.sign(
      "HMAC",
      key,
      BookingLists.stringToBytes(message)
    );
    return btoa(String.fromCharCode(...new Uint8Array(signature)));
  },

  // Function to fetch booking data from API
  getBokunParentBooking: async (bookingId) => {
    console.log("getBokunParentBooking called with ID:", bookingId);
    const base_url = "https://api.bokun.io";
    const path = `/booking.json/booking/${bookingId}?currency=eur`;
    const url = `${base_url}${path}`;
    const currentDate = BookingLists.getCurrentDate();
    const secretKey = "5d79563a209b4b66bf4c76af0cf46aec";
    const accessKey = "e7e5091e907a4de3a9134d5bde470824";
    const httpMethod = "GET";
    const concatenatedString = currentDate + accessKey + httpMethod + path;

    try {
      const signature = await BookingLists.createHmacSha1(
        concatenatedString,
        secretKey
      );

      const response = await fetch(url, {
        method: "GET",
        headers: {
          "X-Bokun-Date": currentDate,
          "X-Bokun-AccessKey": accessKey,
          "X-Bokun-Signature": signature,
        },
      });

      if (response.status === 404) {
        return null;
      }

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();

      // Extract totalAsMoney if available
      if (data?.activityBookings?.[0]?.sellerInvoice) {
        const sellerInvoice = data.activityBookings[0].sellerInvoice;
        const totalAsMoney = sellerInvoice.totalAsMoney.amount;
        console.log("totalAsMoney.amount:", totalAsMoney);
        return { ...data, totalAsMoney };
      }

      return data;
    } catch (error) {
      console.error("Error fetching booking data:", error);
      throw error;
    }
  },

  // Function to create total amount display with copy button
  createTotalAmountDisplay: (totalAmount, bookingId) => {
    const container = document.createElement("div");
    container.style.cssText = `
      position: absolute;
      bottom: 10px;
      right: 10px;
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      border: 1px solid #dee2e6;
      border-radius: 12px;
      padding: 12px 16px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      display: flex;
      align-items: center;
      gap: 8px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      font-weight: 600;
      color: #495057;
      z-index: 1000;
    `;

    const amountText = document.createElement("span");
    amountText.textContent = `€${totalAmount}`;
    amountText.style.cssText = `
      color: #28a745;
      font-weight: 700;
    `;

    const copyButton = document.createElement("button");
    copyButton.textContent = "📋";

    copyButton.style.cssText = `
      background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
      border: none;
      border-radius: 6px;
      padding: 6px;
      cursor: pointer;
      color: white;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 26px;
      height: 26px;
      transition: all 0.2s ease;
      font-size: 12px;
    `;

    copyButton.title = `Copy amount: €${totalAmount}`;

    copyButton.addEventListener("click", async (e) => {
      e.preventDefault();
      e.stopPropagation();
      await Utils.copyToClipboard(totalAmount.toString(), copyButton);
    });

    container.appendChild(amountText);
    container.appendChild(copyButton);

    return container;
  },

  // Function to process booking lists and extract PRO codes
  processBookingLists: async (settings) => {
    if (!settings.processBookingLists) return;

    const bookingTables = document.querySelectorAll("table.bookinglist");

    console.log(`Found ${bookingTables.length} booking tables`);

    for (const [tableIndex, table] of bookingTables.entries()) {
      // Make table container relative for absolute positioning
      if (table.style.position !== "relative") {
        table.style.position = "relative";
      }

      // Check if we already processed this table
      if (table.querySelector(".total-amount-display")) {
        continue;
      }

      const proLinks = table.querySelectorAll('a[href*="/sales/"] strong');

      for (const [linkIndex, strongElement] of Array.from(proLinks).entries()) {
        const proText = strongElement.textContent.trim();
        const numericPart = BookingLists.extractProCodeNumeric(proText);

        if (numericPart) {
          console.log(`Processing booking ID: ${numericPart}`);

          try {
            const bookingData = await BookingLists.getBokunParentBooking(
              numericPart
            );

            if (bookingData && bookingData.totalAsMoney) {
              const totalDisplay = BookingLists.createTotalAmountDisplay(
                bookingData.totalAsMoney,
                numericPart
              );
              totalDisplay.className = "total-amount-display";
              table.appendChild(totalDisplay);
              break; // Only process first PRO code per table
            }
          } catch (error) {
            console.error(
              `Failed to fetch booking data for ID ${numericPart}:`,
              error
            );
          }
        }
      }
    }
  },

  // Function to cleanup booking lists displays
  cleanup: () => {
    document
      .querySelectorAll(".total-amount-display")
      .forEach((el) => el.remove());
  },
};
