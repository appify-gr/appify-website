// connect-phone-packages.js - Enhanced with package selector functionality

const ConnectPhonePackages = {
  // Function to check if current URL matches the target URL (E-Sims page)
  isCorrectURL: () => {
    return window.location.href.includes("https://app.connectphone.gr/sims");
  },

  // Function to get all available packages from the select element
  getAvailablePackages: () => {
    const selectElement = document.querySelector('select[name="offer_id[]"]');
    if (!selectElement) return [];

    const packages = [];
    const options = selectElement.querySelectorAll(
      'option[value]:not([value=""])'
    );

    options.forEach((option) => {
      packages.push({
        id: option.value,
        name: option.textContent.trim(),
      });
    });

    return packages;
  },

  // Function to save package to localStorage
  savePackageToStorage: (packageName, selectedOffers) => {
    try {
      let savedPackages = JSON.parse(
        localStorage.getItem("connectPhonePackages") || "[]"
      );

      const newPackage = {
        id: Date.now(), // Simple ID based on timestamp
        name: packageName,
        offers: selectedOffers,
        createdAt: new Date().toISOString(),
      };

      savedPackages.push(newPackage);
      localStorage.setItem(
        "connectPhonePackages",
        JSON.stringify(savedPackages)
      );

      console.log("Package saved:", newPackage);
      return true;
    } catch (error) {
      console.error("Error saving package:", error);
      return false;
    }
  },

  // Function to get saved packages from localStorage
  getSavedPackages: () => {
    try {
      return JSON.parse(localStorage.getItem("connectPhonePackages") || "[]");
    } catch (error) {
      console.error("Error loading packages:", error);
      return [];
    }
  },

  // Function to delete a package from localStorage
  deletePackageFromStorage: (packageId) => {
    try {
      let savedPackages = JSON.parse(
        localStorage.getItem("connectPhonePackages") || "[]"
      );

      savedPackages = savedPackages.filter((pkg) => pkg.id !== packageId);
      localStorage.setItem(
        "connectPhonePackages",
        JSON.stringify(savedPackages)
      );

      console.log("Package deleted:", packageId);
      return true;
    } catch (error) {
      console.error("Error deleting package:", error);
      return false;
    }
  },

  // Function to create and show loader
  showLoader: (container) => {
    const loader = document.createElement("div");
    loader.className = "package-apply-loader";
    loader.style.cssText = `
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(255, 255, 255, 0.95);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      border-radius: 8px;
      backdrop-filter: blur(2px);
    `;

    const spinner = document.createElement("div");
    spinner.style.cssText = `
      display: flex;
      align-items: center;
      gap: 10px;
      color: #007bff;
      font-size: 14px;
      font-weight: 500;
    `;

    const spinnerIcon = document.createElement("div");
    spinnerIcon.style.cssText = `
      width: 20px;
      height: 20px;
      border: 2px solid #e3f2fd;
      border-top: 2px solid #007bff;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    `;

    // Add CSS animation
    if (!document.querySelector("#package-loader-styles")) {
      const style = document.createElement("style");
      style.id = "package-loader-styles";
      style.textContent = `
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `;
      document.head.appendChild(style);
    }

    const text = document.createElement("span");
    text.textContent = "Applying collection...";

    spinner.appendChild(spinnerIcon);
    spinner.appendChild(text);
    loader.appendChild(spinner);

    // Make container relative for absolute positioning
    container.style.position = "relative";
    container.appendChild(loader);

    return loader;
  },

  // Function to hide loader
  hideLoader: () => {
    const loader = document.querySelector(".package-apply-loader");
    if (loader) {
      loader.remove();
    }
  },

  // Function to wait for jQuery to be available
  waitForjQuery: (callback, timeout = 5000) => {
    const startTime = Date.now();

    const check = () => {
      if (
        typeof window.$ !== "undefined" &&
        window.$.fn &&
        window.$.fn.select2
      ) {
        callback(true);
      } else if (Date.now() - startTime > timeout) {
        console.warn(
          "jQuery/Select2 not available after timeout, trying fallback"
        );
        callback(false);
      } else {
        setTimeout(check, 100);
      }
    };

    check();
  },

  // Function to apply package offers to the main select2 dropdown
  applyPackageToSelect: (offers, onComplete = null) => {
    const mainSelect = document.querySelector('select[name="offer_id[]"]');
    if (!mainSelect) {
      console.error("Main offer select not found");
      if (onComplete) onComplete(false);
      return;
    }

    // Get the offer IDs to select
    const offerIds = offers.map((offer) => offer.id);

    // Try to use jQuery/Select2 if available
    ConnectPhonePackages.waitForjQuery((jQueryAvailable) => {
      if (jQueryAvailable) {
        try {
          // Use jQuery/Select2 methods
          console.log("Using jQuery/Select2 methods");
          window.$(mainSelect).val(null).trigger("change");
          window.$(mainSelect).val(offerIds).trigger("change");
          console.log("Applied offers using jQuery:", offerIds);

          // Wait a bit for the UI to update
          setTimeout(() => {
            if (onComplete) onComplete(true);
          }, 300);
        } catch (error) {
          console.error("Error using jQuery methods, falling back:", error);
          ConnectPhonePackages.applyPackageVanilla(
            mainSelect,
            offerIds,
            onComplete
          );
        }
      } else {
        // Fallback to vanilla JavaScript
        console.log("jQuery not available, using vanilla JavaScript fallback");
        ConnectPhonePackages.applyPackageVanilla(
          mainSelect,
          offerIds,
          onComplete
        );
      }
    });
  },

  // Fallback function to apply packages using vanilla JavaScript
  applyPackageVanilla: (selectElement, offerIds, onComplete = null) => {
    try {
      // Clear current selection
      Array.from(selectElement.options).forEach((option) => {
        option.selected = false;
      });

      // Select the specified offers
      offerIds.forEach((offerId) => {
        const option = selectElement.querySelector(
          `option[value="${offerId}"]`
        );
        if (option) {
          option.selected = true;
        }
      });

      // Trigger change event
      const changeEvent = new Event("change", { bubbles: true });
      selectElement.dispatchEvent(changeEvent);

      // If it's a Select2 dropdown, try to refresh it
      if (selectElement.classList.contains("select2-hidden-accessible")) {
        // Try to trigger Select2 refresh if possible
        setTimeout(() => {
          if (typeof window.$ !== "undefined" && window.$.fn.select2) {
            try {
              window.$(selectElement).trigger("change.select2");
            } catch (e) {
              console.log("Could not trigger Select2 refresh:", e);
            }
          }

          // Wait a bit more for UI to update, then complete
          setTimeout(() => {
            if (onComplete) onComplete(true);
          }, 200);
        }, 100);
      } else {
        // No Select2, complete immediately
        setTimeout(() => {
          if (onComplete) onComplete(true);
        }, 100);
      }

      console.log("Applied offers using vanilla JavaScript:", offerIds);
    } catch (error) {
      console.error("Error in vanilla JavaScript fallback:", error);
      if (onComplete) onComplete(false);
    }
  },

  // Function to create the package selector dropdown
  createPackageSelectorDropdown: () => {
    const savedPackages = ConnectPhonePackages.getSavedPackages();

    if (savedPackages.length === 0) {
      return null;
    }

    // Create container div
    const container = document.createElement("div");
    container.className = "mb-1 package-selector-container";
    container.style.cssText = `
      margin-bottom: 1rem;
      padding: 15px;
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      border-radius: 8px;
      border: 1px solid #dee2e6;
    `;

    // Create label
    const label = document.createElement("label");
    label.className = "form-label";
    label.textContent = "Select Saved Package";
    label.style.cssText = `
      font-weight: 600;
      color: #495057;
      margin-bottom: 8px;
      display: block;
    `;

    // Create select dropdown
    const select = document.createElement("select");
    select.className = "form-control package-selector";
    select.style.cssText = `
      width: 100%;
      padding: 8px 12px;
      border: 2px solid #ced4da;
      border-radius: 6px;
      font-size: 14px;
      background: white;
      transition: border-color 0.3s ease, box-shadow 0.3s ease;
    `;

    // Add default option
    const defaultOption = document.createElement("option");
    defaultOption.value = "";
    defaultOption.textContent = "-- Select a saved collection --";
    select.appendChild(defaultOption);

    // Add saved packages as options
    savedPackages.forEach((pkg) => {
      const option = document.createElement("option");
      option.value = pkg.id;
      option.textContent = `${pkg.name} (${pkg.offers.length} offers)`;
      option.dataset.offers = JSON.stringify(pkg.offers);
      select.appendChild(option);
    });

    // Create action buttons container
    const actionsContainer = document.createElement("div");
    actionsContainer.style.cssText = `
      display: flex;
      gap: 8px;
      margin-top: 10px;
    `;

    // Create apply button
    const applyButton = document.createElement("button");
    applyButton.type = "button";
    applyButton.className = "btn btn-primary btn-sm";
    applyButton.textContent = "Apply Collection";
    applyButton.style.cssText = `
      background: #007bff;
      border: none;
      border-radius: 4px;
      color: white;
      padding: 6px 12px;
      font-size: 12px;
      cursor: pointer;
      transition: background 0.3s ease;
      opacity: 0.6;
    `;
    applyButton.disabled = true;

    // Create delete button
    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "btn btn-danger btn-sm";
    deleteButton.textContent = "Delete Collection";
    deleteButton.style.cssText = `
      background: #dc3545;
      border: none;
      border-radius: 4px;
      color: white;
      padding: 6px 12px;
      font-size: 12px;
      cursor: pointer;
      transition: background 0.3s ease;
      opacity: 0.6;
    `;
    deleteButton.disabled = true;

    // Handle dropdown change
    select.addEventListener("change", (e) => {
      const isPackageSelected = e.target.value !== "";
      applyButton.disabled = !isPackageSelected;
      deleteButton.disabled = !isPackageSelected;
      applyButton.style.opacity = isPackageSelected ? "1" : "0.6";
      deleteButton.style.opacity = isPackageSelected ? "1" : "0.6";
    });

    // Handle apply button click
    applyButton.addEventListener("click", () => {
      const selectedOption = select.options[select.selectedIndex];
      if (selectedOption && selectedOption.dataset.offers) {
        try {
          const offers = JSON.parse(selectedOption.dataset.offers);

          // Show loader
          const loader = ConnectPhonePackages.showLoader(container);

          // Disable button during operation
          applyButton.disabled = true;
          applyButton.style.opacity = "0.6";

          // Apply package with completion callback
          ConnectPhonePackages.applyPackageToSelect(offers, (success) => {
            // Hide loader
            ConnectPhonePackages.hideLoader();

            // Re-enable button
            applyButton.disabled = false;
            applyButton.style.opacity = "1";

            if (success) {
              ConnectPhonePackages.showTemporaryMessage(
                `✅ Applied collection: ${selectedOption.textContent}`
              );
            } else {
              ConnectPhonePackages.showTemporaryMessage(
                "❌ Error applying collection"
              );
            }
          });
        } catch (error) {
          console.error("Error applying package:", error);
          ConnectPhonePackages.hideLoader();
          applyButton.disabled = false;
          applyButton.style.opacity = "1";
          ConnectPhonePackages.showTemporaryMessage(
            "❌ Error applying collection"
          );
        }
      }
    });

    // Handle delete button click
    deleteButton.addEventListener("click", () => {
      const selectedOption = select.options[select.selectedIndex];
      if (selectedOption && selectedOption.value) {
        const packageName = selectedOption.textContent;
        if (confirm(`Are you sure you want to delete "${packageName}"?`)) {
          const success = ConnectPhonePackages.deletePackageFromStorage(
            parseInt(selectedOption.value)
          );

          if (success) {
            // Remove the option from the dropdown
            selectedOption.remove();

            // Reset buttons
            applyButton.disabled = true;
            deleteButton.disabled = true;
            applyButton.style.opacity = "0.6";
            deleteButton.style.opacity = "0.6";

            ConnectPhonePackages.showTemporaryMessage(
              `Package "${packageName}" deleted successfully!`
            );

            // If no packages left, hide the selector
            if (select.options.length <= 1) {
              container.remove();
            }
          } else {
            ConnectPhonePackages.showTemporaryMessage("Error deleting package");
          }
        }
      }
    });

    // Assemble the container
    actionsContainer.appendChild(applyButton);
    actionsContainer.appendChild(deleteButton);
    container.appendChild(label);
    container.appendChild(select);
    container.appendChild(actionsContainer);

    return container;
  },

  // Function to insert package selector into the modal
  insertPackageSelector: () => {
    // Find the modal body
    const modalBody = document.querySelector("#modals-slide-in .modal-body");
    if (!modalBody) {
      console.log("Modal body not found");
      return;
    }

    // Check if selector already exists
    if (modalBody.querySelector(".package-selector-container")) {
      return;
    }

    // Find the 5th div (offer selection div)
    const divs = modalBody.querySelectorAll(".mb-1");
    if (divs.length >= 5) {
      const offerDiv = divs[4]; // 5th div (0-indexed)

      // Create the package selector
      const packageSelector =
        ConnectPhonePackages.createPackageSelectorDropdown();

      if (packageSelector) {
        // Insert the package selector before the offer selection div
        modalBody.insertBefore(packageSelector, offerDiv);
        console.log("Package selector inserted successfully");
      }
    }
  },

  // Function to create the package creation modal
  createPackageModal: () => {
    const modal = document.createElement("div");
    modal.className = "package-modal";
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.7);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 10000;
      backdrop-filter: blur(5px);
    `;

    const container = document.createElement("div");
    container.style.cssText = `
      background: white;
      border-radius: 16px;
      padding: 30px;
      max-width: 600px;
      max-height: 80vh;
      width: 90vw;
      display: flex;
      flex-direction: column;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;

    // Header
    const header = document.createElement("div");
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
      padding-bottom: 15px;
      border-bottom: 2px solid #f0f0f0;
    `;

    const title = document.createElement("h2");
    title.textContent = "Create Collection";
    title.style.cssText = `
      margin: 0;
      color: #333;
      font-size: 24px;
      font-weight: 600;
    `;

    const closeButton = document.createElement("button");
    closeButton.innerHTML = "&times;";
    closeButton.style.cssText = `
      background: none;
      border: none;
      font-size: 32px;
      color: #999;
      cursor: pointer;
      padding: 0;
      width: 40px;
      height: 40px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 50%;
      transition: all 0.3s ease;
    `;

    // Search box
    const searchContainer = document.createElement("div");
    searchContainer.style.cssText = `
      margin-bottom: 20px;
    `;

    const searchInput = document.createElement("input");
    searchInput.type = "text";
    searchInput.placeholder = "Search packages...";
    searchInput.style.cssText = `
      width: 100%;
      padding: 12px 16px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 14px;
      box-sizing: border-box;
      transition: border-color 0.3s ease;
    `;

    // Package list container
    const packageListContainer = document.createElement("div");
    packageListContainer.style.cssText = `
      flex: 1;
      max-height: 400px;
      overflow-y: auto;
      border: 2px solid #f0f0f0;
      border-radius: 8px;
      padding: 10px;
      margin-bottom: 20px;
    `;

    // Selected count
    const selectedCount = document.createElement("div");
    selectedCount.style.cssText = `
      margin-bottom: 15px;
      padding: 8px 12px;
      background: #e3f2fd;
      border-radius: 6px;
      color: #1976d2;
      font-size: 14px;
      font-weight: 500;
    `;
    selectedCount.textContent = "Selected: 0 packages";

    // Buttons container
    const buttonsContainer = document.createElement("div");
    buttonsContainer.style.cssText = `
      display: flex;
      gap: 12px;
      justify-content: flex-end;
    `;

    const cancelButton = document.createElement("button");
    cancelButton.textContent = "Cancel";
    cancelButton.style.cssText = `
      background: #6c757d;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 12px 24px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.3s ease;
    `;

    const saveButton = document.createElement("button");
    saveButton.textContent = "Save Package";
    saveButton.style.cssText = `
      background: #28a745;
      color: white;
      border: none;
      border-radius: 8px;
      padding: 12px 24px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      transition: background 0.3s ease;
    `;

    // Build the modal structure
    header.appendChild(title);
    header.appendChild(closeButton);
    searchContainer.appendChild(searchInput);
    buttonsContainer.appendChild(cancelButton);
    buttonsContainer.appendChild(saveButton);

    container.appendChild(header);
    container.appendChild(searchContainer);
    container.appendChild(selectedCount);
    container.appendChild(packageListContainer);
    container.appendChild(buttonsContainer);
    modal.appendChild(container);

    return {
      modal,
      container,
      closeButton,
      cancelButton,
      saveButton,
      searchInput,
      packageListContainer,
      selectedCount,
    };
  },

  // Function to create package item element
  createPackageItem: (packageData, isSelected = false) => {
    const item = document.createElement("div");
    item.className = "package-item";
    item.style.cssText = `
      display: flex;
      align-items: center;
      padding: 12px;
      border: 2px solid ${isSelected ? "#28a745" : "#e0e0e0"};
      border-radius: 8px;
      margin-bottom: 8px;
      cursor: pointer;
      transition: all 0.3s ease;
      background: ${isSelected ? "#f8fff8" : "white"};
    `;

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = isSelected;
    checkbox.style.cssText = `
      margin-right: 12px;
      transform: scale(1.2);
    `;

    const label = document.createElement("label");
    label.textContent = packageData.name;
    label.style.cssText = `
      flex: 1;
      cursor: pointer;
      font-size: 14px;
      color: #333;
      line-height: 1.4;
    `;

    item.appendChild(checkbox);
    item.appendChild(label);

    // Toggle selection on click
    item.addEventListener("click", (e) => {
      if (e.target !== checkbox) {
        checkbox.checked = !checkbox.checked;
      }

      if (checkbox.checked) {
        item.style.border = "2px solid #28a745";
        item.style.background = "#f8fff8";
      } else {
        item.style.border = "2px solid #e0e0e0";
        item.style.background = "white";
      }

      // Trigger selection count update
      checkbox.dispatchEvent(new Event("change"));
    });

    checkbox.addEventListener("change", (e) => {
      e.stopPropagation();
    });

    return { item, checkbox };
  },

  // Function to show package creation modal
  showPackageModal: () => {
    const availablePackages = ConnectPhonePackages.getAvailablePackages();

    if (availablePackages.length === 0) {
      ConnectPhonePackages.showTemporaryMessage(
        "No packages found on this page!"
      );
      return;
    }

    const {
      modal,
      closeButton,
      cancelButton,
      saveButton,
      searchInput,
      packageListContainer,
      selectedCount,
    } = ConnectPhonePackages.createPackageModal();

    document.body.appendChild(modal);

    let packageItems = [];
    // NEW: Add selectedPackageIds Set to persist selection state
    let selectedPackageIds = new Set();

    // Function to render packages
    const renderPackages = (packages) => {
      packageListContainer.innerHTML = "";
      packageItems = [];

      packages.forEach((pkg) => {
        // NEW: Check if this package was previously selected
        const isSelected = selectedPackageIds.has(pkg.id);
        const { item, checkbox } = ConnectPhonePackages.createPackageItem(
          pkg,
          isSelected
        );
        packageItems.push({ element: item, checkbox, data: pkg });
        packageListContainer.appendChild(item);

        checkbox.addEventListener("change", (e) => {
          // NEW: Update the selectedPackageIds Set when checkbox changes
          if (e.target.checked) {
            selectedPackageIds.add(pkg.id);
          } else {
            selectedPackageIds.delete(pkg.id);
          }
          updateSelectedCount();
        });
      });

      updateSelectedCount();
    };

    // Function to update selected count
    const updateSelectedCount = () => {
      // NEW: Use selectedPackageIds.size instead of counting DOM elements
      const selected = selectedPackageIds.size;
      selectedCount.textContent = `Selected: ${selected} packages`;
      saveButton.disabled = selected === 0;
      saveButton.style.opacity = selected === 0 ? "0.5" : "1";
    };

    // Search functionality
    searchInput.addEventListener("input", (e) => {
      const searchTerm = e.target.value.toLowerCase();
      const filteredPackages = availablePackages.filter((pkg) =>
        pkg.name.toLowerCase().includes(searchTerm)
      );
      renderPackages(filteredPackages);
    });

    // Close modal handlers
    const closeModal = () => {
      modal.remove();
    };

    closeButton.addEventListener("click", closeModal);
    cancelButton.addEventListener("click", closeModal);
    modal.addEventListener("click", (e) => {
      if (e.target === modal) closeModal();
    });

    // Save button handler
    saveButton.addEventListener("click", () => {
      // NEW: Get selected offers using selectedPackageIds Set
      const selectedOffers = availablePackages.filter((pkg) =>
        selectedPackageIds.has(pkg.id)
      );

      if (selectedOffers.length === 0) {
        ConnectPhonePackages.showTemporaryMessage(
          "Please select at least one package!"
        );
        return;
      }

      // Show prompt for package name
      const packageName = prompt("Enter package name:");

      if (packageName && packageName.trim()) {
        const success = ConnectPhonePackages.savePackageToStorage(
          packageName.trim(),
          selectedOffers
        );

        if (success) {
          ConnectPhonePackages.showTemporaryMessage(
            `Package "${packageName}" saved successfully!`
          );
          closeModal();

          // Refresh package selector if modal is open
          setTimeout(() => {
            ConnectPhonePackages.insertPackageSelector();
          }, 100);
        } else {
          ConnectPhonePackages.showTemporaryMessage(
            "Error saving package. Please try again."
          );
        }
      } else if (packageName !== null) {
        ConnectPhonePackages.showTemporaryMessage("Package name is required!");
      }
    });

    // Initial render
    renderPackages(availablePackages);
  },

  // Function to create the "Create Package" button
  createPackageButton: () => {
    const button = document.createElement("button");
    button.className = "dt-button create-package mx-50 btn btn-success";
    button.type = "button";
    button.tabIndex = 0;
    button.setAttribute("aria-controls", "DataTables_Table_0");

    // Create button content with icon and text
    const span = document.createElement("span");
    span.style.cssText = `
      display: flex;
      align-items: center;
      gap: 8px;
    `;

    // Add package icon (using feather icon style)
    const icon = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    icon.setAttribute("xmlns", "http://www.w3.org/2000/svg");
    icon.setAttribute("width", "24");
    icon.setAttribute("height", "24");
    icon.setAttribute("viewBox", "0 0 24 24");
    icon.setAttribute("fill", "none");
    icon.setAttribute("stroke", "currentColor");
    icon.setAttribute("stroke-width", "2");
    icon.setAttribute("stroke-linecap", "round");
    icon.setAttribute("stroke-linejoin", "round");
    icon.className = "feather feather-package font-small-4";

    // Create package icon path
    const path1 = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "path"
    );
    path1.setAttribute("d", "M16.5 9.4 7.55 4.24");

    const path2 = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "path"
    );
    path2.setAttribute(
      "d",
      "M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"
    );

    const polyline1 = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "polyline"
    );
    polyline1.setAttribute("points", "3.29 7 12 12 20.71 7");

    const line1 = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "line"
    );
    line1.setAttribute("x1", "12");
    line1.setAttribute("y1", "22");
    line1.setAttribute("x2", "12");
    line1.setAttribute("y2", "12");

    icon.appendChild(path1);
    icon.appendChild(path2);
    icon.appendChild(polyline1);
    icon.appendChild(line1);

    // Create text node
    const textNode = document.createTextNode("Create Collection");

    span.appendChild(icon);
    span.appendChild(textNode);
    button.appendChild(span);

    // Add click event handler to show modal
    button.addEventListener("click", (e) => {
      e.preventDefault();
      ConnectPhonePackages.showPackageModal();
    });

    return button;
  },

  // Function to show temporary message
  showTemporaryMessage: (message) => {
    const messageDiv = document.createElement("div");
    messageDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
      z-index: 10001;
      font-size: 14px;
      font-weight: 500;
      opacity: 0;
      transition: opacity 0.3s ease;
    `;

    messageDiv.textContent = message;
    document.body.appendChild(messageDiv);

    // Animate in
    setTimeout(() => {
      messageDiv.style.opacity = "1";
    }, 100);

    // Remove after 3 seconds
    setTimeout(() => {
      messageDiv.style.opacity = "0";
      setTimeout(() => {
        if (messageDiv.parentNode) {
          messageDiv.remove();
        }
      }, 300);
    }, 3000);
  },

  // Function to watch for modal opens and insert package selector
  watchForModalOpen: () => {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (
          mutation.type === "attributes" &&
          mutation.attributeName === "style"
        ) {
          const modal = document.querySelector("#modals-slide-in");
          if (modal && modal.style.display === "block") {
            // Modal is now open, insert package selector
            setTimeout(() => {
              ConnectPhonePackages.insertPackageSelector();
            }, 200);
          }
        }
      });
    });

    const modal = document.querySelector("#modals-slide-in");
    if (modal) {
      observer.observe(modal, {
        attributes: true,
        attributeFilter: ["style", "class"],
      });
    }
  },

  // Function to process connect phone packages functionality
  processConnectPhonePackages: (settings) => {
    if (!settings.connectPhonePackages) return;

    // Check if we're on the correct URL
    if (!ConnectPhonePackages.isCorrectURL()) {
      console.log(
        "Connect phone packages tweak: Not on E-Sims page, skipping..."
      );
      return;
    }

    // Try multiple selectors to find the dt-buttons container
    let dtButtonsContainer = document.querySelector(
      ".dt-buttons.d-inline-flex"
    );

    if (!dtButtonsContainer) {
      dtButtonsContainer = document.querySelector(".dt-buttons");
    }

    if (!dtButtonsContainer) {
      dtButtonsContainer = document.querySelector("[class*='dt-buttons']");
    }

    if (!dtButtonsContainer) {
      console.log(
        "Connect phone packages tweak: dt-buttons container not found, will retry..."
      );
      // Don't return here - let the MutationObserver handle retries
      return;
    }

    // Check if button already exists
    if (dtButtonsContainer.querySelector(".create-package")) {
      console.log("Connect phone packages tweak: Button already exists");
      return;
    }

    // Create and insert the button
    const packageButton = ConnectPhonePackages.createPackageButton();

    // Insert the button as the first button in the container
    dtButtonsContainer.insertBefore(
      packageButton,
      dtButtonsContainer.firstChild
    );

    // Start watching for modal opens
    ConnectPhonePackages.watchForModalOpen();

    console.log(
      "Connect phone packages tweak: Create Package button added successfully"
    );
  },

  // Function to cleanup connect phone packages elements
  cleanup: () => {
    document.querySelectorAll(".create-package").forEach((el) => el.remove());
    document.querySelectorAll(".package-modal").forEach((el) => el.remove());
    document
      .querySelectorAll(".package-selector-container")
      .forEach((el) => el.remove());
  },
};
