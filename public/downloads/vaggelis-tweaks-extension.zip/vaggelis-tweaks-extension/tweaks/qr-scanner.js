// qr-scanner.js - Handles QR code scanning functionality

const QRScanner = {
  // Function to create QR scanner button with modern styling
  createQRScanButton: () => {
    const button = document.createElement("button");
    button.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M9 12l2 2 4-4"></path>
        <path d="M21 12c.552 0 1-.448 1-1V5c0-.552-.448-1-1-1h-6c-.552 0-1 .448-1 1v6c0 .552.448 1 1 1h6z"></path>
        <path d="M3 12c-.552 0-1-.448-1-1V5c0-.552.448-1 1-1h6c.552 0 1 .448 1 1v6c0 .552-.448 1-.552 1H3z"></path>
        <path d="M21 22c.552 0 1-.448 1-1v-6c0-.552-.448-1-1-1h-6c-.552 0-1 .448-1 1v6c0 .552.448 1 1 1h6z"></path>
        <path d="M3 22c-.552 0-1-.448-1-1v-6c0-.552.448-1 1-1h6c.552 0 1 .448 1 1v6c0 .552-.448 1-1 1H3z"></path>
      </svg>
    `;
    button.type = "button";

    button.style.cssText = `
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      background: transparent;
      border: none;
      padding: 6px;
      cursor: pointer;
      color: #6c757d;
      transition: all 0.2s ease;
      border-radius: 6px;
      display: flex;
      align-items: center;
      justify-content: center;
      width: 28px;
      height: 28px;
      z-index: 10;
    `;

    button.title = "Scan QR Code";
    button.className = "qr-scan-btn";

    // Hover effects
    button.addEventListener("mouseenter", () => {
      button.style.background = "rgba(13, 110, 253, 0.1)";
      button.style.color = "#0d6efd";
      button.style.transform = "translateY(-50%) scale(1.1)";
    });

    button.addEventListener("mouseleave", () => {
      button.style.background = "transparent";
      button.style.color = "#6c757d";
      button.style.transform = "translateY(-50%) scale(1)";
    });

    return button;
  },

  // Function to style the input field container
  styleInputContainer: (inputField) => {
    const parentDiv = inputField.parentNode;

    // Create input wrapper if it doesn't exist
    if (!parentDiv.querySelector(".input-group-wrapper")) {
      const wrapper = document.createElement("div");
      wrapper.className = "input-group-wrapper";
      wrapper.style.cssText = `
        position: relative;
        display: flex;
        align-items: center;
      `;

      parentDiv.insertBefore(wrapper, inputField);
      wrapper.appendChild(inputField);

      // Add padding to input to make room for button
      inputField.style.paddingRight = "45px";

      return wrapper;
    }

    return parentDiv.querySelector(".input-group-wrapper");
  },

  // Function to create modern camera modal
  createCameraModal: () => {
    const modal = document.createElement("div");
    modal.className = "qr-camera-modal";
    modal.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.75);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 10000;
      backdrop-filter: blur(8px);
      opacity: 0;
      transition: opacity 0.3s ease;
    `;

    // Animate modal in
    setTimeout(() => {
      modal.style.opacity = "1";
    }, 10);

    const container = document.createElement("div");
    container.style.cssText = `
      background: #ffffff;
      border-radius: 16px;
      padding: 32px;
      max-width: 480px;
      width: 90vw;
      max-height: 90vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      transform: scale(0.9);
      transition: transform 0.3s ease;
      overflow: hidden;
    `;

    // Animate container in
    setTimeout(() => {
      container.style.transform = "scale(1)";
    }, 10);

    const header = document.createElement("div");
    header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      margin-bottom: 24px;
    `;

    const title = document.createElement("h3");
    title.textContent = "Scan QR Code";
    title.style.cssText = `
      margin: 0;
      color: #1a1a1a;
      font-size: 24px;
      font-weight: 600;
    `;

    const closeButton = document.createElement("button");
    closeButton.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    `;
    closeButton.style.cssText = `
      background: transparent;
      border: none;
      color: #6c757d;
      cursor: pointer;
      padding: 8px;
      border-radius: 8px;
      transition: all 0.2s ease;
      display: flex;
      align-items: center;
      justify-content: center;
    `;

    closeButton.addEventListener("mouseenter", () => {
      closeButton.style.background = "#f8f9fa";
      closeButton.style.color = "#dc3545";
    });

    closeButton.addEventListener("mouseleave", () => {
      closeButton.style.background = "transparent";
      closeButton.style.color = "#6c757d";
    });

    const videoContainer = document.createElement("div");
    videoContainer.style.cssText = `
      position: relative;
      width: 100%;
      max-width: 360px;
      border-radius: 12px;
      overflow: hidden;
      margin-bottom: 24px;
      background: #000;
    `;

    const video = document.createElement("video");
    video.style.cssText = `
      width: 100%;
      height: auto;
      display: block;
    `;
    video.autoplay = true;
    video.playsInline = true;

    const canvas = document.createElement("canvas");
    canvas.style.display = "none";

    const status = document.createElement("div");
    status.style.cssText = `
      padding: 12px 20px;
      border-radius: 8px;
      font-size: 14px;
      text-align: center;
      background: linear-gradient(135deg, #e3f2fd 0%, #f3e5f5 100%);
      color: #1976d2;
      border: 1px solid #e1f5fe;
      margin-bottom: 20px;
      min-width: 280px;
      font-weight: 500;
    `;
    status.textContent = "Position QR code in front of camera";

    const buttonContainer = document.createElement("div");
    buttonContainer.style.cssText = `
      display: flex;
      gap: 12px;
      margin-top: 8px;
    `;

    const cancelButton = document.createElement("button");
    cancelButton.textContent = "Cancel";
    cancelButton.style.cssText = `
      background: #ffffff;
      color: #6c757d;
      border: 2px solid #e9ecef;
      border-radius: 8px;
      padding: 12px 24px;
      cursor: pointer;
      font-size: 14px;
      font-weight: 500;
      transition: all 0.2s ease;
      min-width: 100px;
    `;

    cancelButton.addEventListener("mouseenter", () => {
      cancelButton.style.background = "#f8f9fa";
      cancelButton.style.borderColor = "#dc3545";
      cancelButton.style.color = "#dc3545";
    });

    cancelButton.addEventListener("mouseleave", () => {
      cancelButton.style.background = "#ffffff";
      cancelButton.style.borderColor = "#e9ecef";
      cancelButton.style.color = "#6c757d";
    });

    header.appendChild(title);
    header.appendChild(closeButton);
    videoContainer.appendChild(video);
    buttonContainer.appendChild(cancelButton);

    container.appendChild(header);
    container.appendChild(videoContainer);
    container.appendChild(canvas);
    container.appendChild(status);
    container.appendChild(buttonContainer);
    modal.appendChild(container);

    return { modal, video, canvas, closeButton, cancelButton, status };
  },

  // Function to decode QR code from image data using jsQR
  decodeQRCode: (imageData) => {
    try {
      // Use jsQR library to decode QR codes
      if (typeof jsQR !== "undefined") {
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        return code ? code.data : null;
      } else {
        console.error("jsQR library not loaded");
        return null;
      }
    } catch (error) {
      console.error("QR decoding error:", error);
      return null;
    }
  },

  // Function to start QR scanning
  startQRScanning: (emailInput) => {
    // Check if jsQR is available
    if (typeof jsQR === "undefined") {
      alert(
        "QR code scanning library not available. Please reload the extension."
      );
      return;
    }

    const { modal, video, canvas, closeButton, cancelButton, status } =
      QRScanner.createCameraModal();

    document.body.appendChild(modal);

    let stream = null;
    let scanInterval = null;

    const cleanup = () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop());
      }
      if (scanInterval) {
        clearInterval(scanInterval);
      }

      // Animate modal out
      modal.style.opacity = "0";
      setTimeout(() => {
        modal.remove();
      }, 300);
    };

    // Add event listeners to both close buttons
    closeButton.addEventListener("click", cleanup);
    cancelButton.addEventListener("click", cleanup);
    modal.addEventListener("click", (e) => {
      if (e.target === modal) cleanup();
    });

    // Start camera
    navigator.mediaDevices
      .getUserMedia({
        video: {
          facingMode: "environment", // Use back camera if available
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
      })
      .then((mediaStream) => {
        stream = mediaStream;
        video.srcObject = mediaStream;

        video.addEventListener("loadedmetadata", () => {
          canvas.width = video.videoWidth;
          canvas.height = video.videoHeight;

          // Start scanning for QR codes
          scanInterval = setInterval(() => {
            if (video.readyState === video.HAVE_ENOUGH_DATA) {
              const context = canvas.getContext("2d");
              context.drawImage(video, 0, 0, canvas.width, canvas.height);

              const imageData = context.getImageData(
                0,
                0,
                canvas.width,
                canvas.height
              );

              // Use real QR code detection
              const qrData = QRScanner.decodeQRCode(imageData);

              if (qrData) {
                status.textContent = "✓ QR Code detected successfully!";
                status.style.background =
                  "linear-gradient(135deg, #e8f5e8 0%, #f1f8e9 100%)";
                status.style.color = "#2e7d2e";
                status.style.borderColor = "#c8e6c9";

                emailInput.value = qrData;
                emailInput.focus();

                // Dispatch input event to trigger any listeners
                emailInput.dispatchEvent(new Event("input", { bubbles: true }));
                emailInput.dispatchEvent(
                  new Event("change", { bubbles: true })
                );

                setTimeout(cleanup, 1500);
              }
            }
          }, 100); // Increased frequency for better detection
        });
      })
      .catch((error) => {
        console.error("Error accessing camera:", error);
        status.textContent = "⚠ Camera access denied or unavailable";
        status.style.background =
          "linear-gradient(135deg, #ffebee 0%, #fce4ec 100%)";
        status.style.color = "#c62828";
        status.style.borderColor = "#ffcdd2";
      });
  },

  // Function to process QR scanner functionality
  processQRScanner: (settings) => {
    if (!settings.qrScanner) return;

    const emailInput = document.getElementById("basic-icon-default-email");

    if (emailInput && !emailInput.parentNode.querySelector(".qr-scan-btn")) {
      // Style the input container
      const wrapper = QRScanner.styleInputContainer(emailInput);

      // Create and add the QR button
      const qrButton = QRScanner.createQRScanButton();

      qrButton.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();

        // Check if camera is supported
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
          alert("Camera access is not supported in this browser");
          return;
        }

        QRScanner.startQRScanning(emailInput);
      });

      // Add button to wrapper
      wrapper.appendChild(qrButton);
    }
  },

  // Function to cleanup QR scanner elements
  cleanup: () => {
    document.querySelectorAll(".qr-scan-btn").forEach((el) => el.remove());
    document.querySelectorAll(".qr-camera-modal").forEach((el) => el.remove());
    document.querySelectorAll(".input-group-wrapper").forEach((wrapper) => {
      const input = wrapper.querySelector("input");
      if (input) {
        input.style.paddingRight = "";
        wrapper.parentNode.insertBefore(input, wrapper);
        wrapper.remove();
      }
    });
  },
};
