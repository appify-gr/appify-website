const tweak = () => {
  console.log("Tweak script loaded");

  // Settings object to hold current state
  let settings = {
    processBookingLists: true,
    processInvoiceTotals: true,
    connectPhoneAppCopyOrder: true,
    qrScanner: true,
    connectPhonePackages: true,
  };

  // Load settings from storage
  const loadSettings = () => {
    chrome.storage.local.get(
      [
        "processBookingLists",
        "processInvoiceTotals",
        "connectPhoneAppCopyOrder",
        "qrScanner",
        "connectPhonePackages",
      ],
      (result) => {
        settings.processBookingLists = result.processBookingLists !== false;
        settings.processInvoiceTotals = result.processInvoiceTotals !== false;
        settings.connectPhoneAppCopyOrder =
          result.connectPhoneAppCopyOrder !== false;
        settings.qrScanner = result.qrScanner !== false;
        settings.connectPhonePackages = result.connectPhonePackages !== false;

        console.log("Settings loaded:", settings);

        // Run initial processing based on settings
        if (settings.processInvoiceTotals) {
          InvoiceTotals.processInvoiceTotals(settings);
        }
        if (settings.processBookingLists) {
          BookingLists.processBookingLists(settings);
        }
        if (settings.connectPhoneAppCopyOrder) {
          ConnectPhoneApp.processConnectPhoneAppCopyOrder(settings);
        }
        if (settings.qrScanner) {
          QRScanner.processQRScanner(settings);
        }
        if (settings.connectPhonePackages) {
          ConnectPhonePackages.processConnectPhonePackages(settings);
        }
      }
    );
  };

  // Listen for settings updates from popup
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "updateSettings") {
      if (request.hasOwnProperty("processBookingLists")) {
        settings.processBookingLists = request.processBookingLists;
        console.log(
          "Booking lists setting updated:",
          settings.processBookingLists
        );

        if (settings.processBookingLists) {
          BookingLists.processBookingLists(settings);
        } else {
          // Remove existing booking list displays
          BookingLists.cleanup();
        }
      }

      if (request.hasOwnProperty("processInvoiceTotals")) {
        settings.processInvoiceTotals = request.processInvoiceTotals;
        console.log(
          "Invoice totals setting updated:",
          settings.processInvoiceTotals
        );

        if (settings.processInvoiceTotals) {
          InvoiceTotals.processInvoiceTotals(settings);
        } else {
          // Remove existing copy buttons
          InvoiceTotals.cleanup();
        }
      }

      if (request.hasOwnProperty("connectPhoneAppCopyOrder")) {
        settings.connectPhoneAppCopyOrder = request.connectPhoneAppCopyOrder;
        console.log(
          "Connect phone app copy order setting updated:",
          settings.connectPhoneAppCopyOrder
        );

        if (settings.connectPhoneAppCopyOrder) {
          ConnectPhoneApp.processConnectPhoneAppCopyOrder(settings);
        } else {
          // Remove existing copy order buttons and cells
          ConnectPhoneApp.cleanup();
        }
      }

      if (request.hasOwnProperty("qrScanner")) {
        settings.qrScanner = request.qrScanner;
        console.log("QR Scanner setting updated:", settings.qrScanner);

        if (settings.qrScanner) {
          QRScanner.processQRScanner(settings);
        } else {
          // Remove existing QR scanner buttons
          QRScanner.cleanup();
        }
      }

      if (request.hasOwnProperty("connectPhonePackages")) {
        settings.connectPhonePackages = request.connectPhonePackages;
        console.log(
          "Connect Phone Packages setting updated:",
          settings.connectPhonePackages
        );

        if (settings.connectPhonePackages) {
          ConnectPhonePackages.processConnectPhonePackages(settings);
        } else {
          // Remove existing Connect Phone Packages buttons
          ConnectPhonePackages.cleanup();
        }
      }

      sendResponse({ success: true });
    }
  });

  // Load settings and run initial processing
  loadSettings();

  // Watch for dynamically added content
  const observer = new MutationObserver((mutations) => {
    let shouldProcess = false;
    let shouldProcessBookings = false;
    let shouldProcessCopyOrder = false;
    let shouldProcessQRScanner = false;
    let shouldProcessConnectPhonePackages = false;

    mutations.forEach((mutation) => {
      if (mutation.type === "childList") {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            if (
              node.classList?.contains("invoice-total") ||
              node.querySelector?.(".invoice-total")
            ) {
              shouldProcess = true;
            }
            if (
              node.classList?.contains("bookinglist") ||
              node.querySelector?.(".bookinglist")
            ) {
              shouldProcessBookings = true;
            }
            if (node.tagName === "TR" || node.querySelector?.("tr")) {
              shouldProcessCopyOrder = true;
            }
            if (
              node.id === "basic-icon-default-email" ||
              node.querySelector?.("#basic-icon-default-email")
            ) {
              shouldProcessQRScanner = true;
            }
            if (
              node.classList?.contains("dt-buttons") ||
              node.querySelector?.(".dt-buttons") ||
              node.classList?.contains("dataTables_wrapper")
            ) {
              shouldProcessConnectPhonePackages = true;
            }
          }
        });
      }
    });

    if (shouldProcess && settings.processInvoiceTotals) {
      setTimeout(() => InvoiceTotals.processInvoiceTotals(settings), 100);
    }

    if (shouldProcessBookings && settings.processBookingLists) {
      setTimeout(() => BookingLists.processBookingLists(settings), 100);
    }

    if (shouldProcessCopyOrder && settings.connectPhoneAppCopyOrder) {
      setTimeout(
        () => ConnectPhoneApp.processConnectPhoneAppCopyOrder(settings),
        100
      );
    }

    if (shouldProcessQRScanner && settings.qrScanner) {
      setTimeout(() => QRScanner.processQRScanner(settings), 100);
    }

    if (shouldProcessConnectPhonePackages && settings.connectPhonePackages) {
      setTimeout(
        () => ConnectPhonePackages.processConnectPhonePackages(settings),
        200
      );
    }
  });

  // Start observing
  observer.observe(document.body, {
    childList: true,
    subtree: true,
  });
};

tweak();
