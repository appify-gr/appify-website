document.addEventListener("DOMContentLoaded", () => {
  // Check if the chrome.runtime API is available
  if (chrome.runtime && chrome.runtime.getManifest) {
    const manifest = chrome.runtime.getManifest();
    const versionElement = document.getElementById("version");
    versionElement.textContent = `Version: ${manifest.version}`;
  } else {
    console.error(
      "chrome.runtime.getManifest() is not available in this context."
    );
  }

  // Get switches
  const processBookingListsSwitch = document.getElementById(
    "processBookingLists"
  );
  const processInvoiceTotalsSwitch = document.getElementById(
    "processInvoiceTotals"
  );
  const connectPhoneAppCopyOrderSwitch = document.getElementById(
    "connectPhoneAppCopyOrder"
  );
  const qrScannerSwitch = document.getElementById("qrScanner");
  const connectPhonePackagesSwitch = document.getElementById(
    "connectPhonePackages"
  );
  const bookingListsStatus = document.getElementById("bookingListsStatus");
  const invoiceTotalsStatus = document.getElementById("invoiceTotalsStatus");
  const connectPhoneAppStatus = document.getElementById(
    "connectPhoneAppStatus"
  );
  const qrScannerStatus = document.getElementById("qrScannerStatus");
  const connectPhonePackagesStatus = document.getElementById(
    "connectPhonePackagesStatus"
  );

  // Load settings from storage
  chrome.storage.local.get(
    [
      "processBookingLists",
      "processInvoiceTotals",
      "connectPhoneAppCopyOrder",
      "qrScanner",
      "connectPhonePackages",
    ],
    (result) => {
      // Default to true if not set
      const bookingListsEnabled = result.processBookingLists !== false;
      const invoiceTotalsEnabled = result.processInvoiceTotals !== false;
      const connectPhoneAppEnabled = result.connectPhoneAppCopyOrder !== false;
      const qrScannerEnabled = result.qrScanner !== false;
      const connectPhonePackagesEnabled = result.connectPhonePackages !== false;

      processBookingListsSwitch.checked = bookingListsEnabled;
      processInvoiceTotalsSwitch.checked = invoiceTotalsEnabled;
      connectPhoneAppCopyOrderSwitch.checked = connectPhoneAppEnabled;
      qrScannerSwitch.checked = qrScannerEnabled;
      connectPhonePackagesSwitch.checked = connectPhonePackagesEnabled;

      updateStatus(bookingListsStatus, bookingListsEnabled);
      updateStatus(invoiceTotalsStatus, invoiceTotalsEnabled);
      updateStatus(connectPhoneAppStatus, connectPhoneAppEnabled);
      updateStatus(qrScannerStatus, qrScannerEnabled);
      updateStatus(connectPhonePackagesStatus, connectPhonePackagesEnabled);
    }
  );

  // Function to update status text
  function updateStatus(statusElement, enabled) {
    statusElement.textContent = enabled ? "Enabled" : "Disabled";
    statusElement.style.color = enabled ? "#28a745" : "#dc3545";
  }

  // Save settings when switches change
  processBookingListsSwitch.addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ processBookingLists: enabled });
    updateStatus(bookingListsStatus, enabled);

    // Notify content script of the change
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "updateSettings",
        processBookingLists: enabled,
      });
    });
  });

  processInvoiceTotalsSwitch.addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ processInvoiceTotals: enabled });
    updateStatus(invoiceTotalsStatus, enabled);

    // Notify content script of the change
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "updateSettings",
        processInvoiceTotals: enabled,
      });
    });
  });

  connectPhoneAppCopyOrderSwitch.addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ connectPhoneAppCopyOrder: enabled });
    updateStatus(connectPhoneAppStatus, enabled);

    // Notify content script of the change
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "updateSettings",
        connectPhoneAppCopyOrder: enabled,
      });
    });
  });

  qrScannerSwitch.addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ qrScanner: enabled });
    updateStatus(qrScannerStatus, enabled);

    // Notify content script of the change
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "updateSettings",
        qrScanner: enabled,
      });
    });
  });

  connectPhonePackagesSwitch.addEventListener("change", (e) => {
    const enabled = e.target.checked;
    chrome.storage.local.set({ connectPhonePackages: enabled });
    updateStatus(connectPhonePackagesStatus, enabled);

    // Notify content script of the change
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, {
        action: "updateSettings",
        connectPhonePackages: enabled,
      });
    });
  });
});
