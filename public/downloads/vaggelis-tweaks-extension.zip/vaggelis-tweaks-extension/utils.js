// utils.js - Shared utility functions

const Utils = {
  // Function to show success feedback
  showSuccessFeedback: (button, copiedValue) => {
    const originalContent = button.textContent;
    const originalBackground = button.style.background;

    // Success emoji
    button.textContent = "✅";

    button.style.background =
      "linear-gradient(135deg, #56ab2f 0%, #a8e6cf 100%)";

    // Create tooltip
    const tooltip = document.createElement("div");
    tooltip.textContent = `Copied: ${copiedValue.substring(0, 50)}${
      copiedValue.length > 50 ? "..." : ""
    }`;
    tooltip.style.cssText = `
      position: absolute;
      background: #333;
      color: white;
      padding: 6px 12px;
      border-radius: 6px;
      font-size: 12px;
      white-space: nowrap;
      z-index: 10000;
      top: -40px;
      left: 50%;
      transform: translateX(-50%);
      opacity: 0;
      transition: opacity 0.3s ease;
      pointer-events: none;
    `;

    // Position tooltip relative to button
    button.style.position = "relative";
    button.appendChild(tooltip);

    // Animate tooltip
    setTimeout(() => {
      tooltip.style.opacity = "1";
    }, 50);

    // Reset after 2 seconds
    setTimeout(() => {
      tooltip.style.opacity = "0";
      setTimeout(() => {
        button.textContent = originalContent;
        button.style.background = originalBackground;
        if (tooltip.parentNode) {
          tooltip.remove();
        }
      }, 300);
    }, 2000);
  },

  // Function to copy to clipboard
  copyToClipboard: async (text, button) => {
    try {
      await navigator.clipboard.writeText(text);
      Utils.showSuccessFeedback(button, text);
    } catch (err) {
      console.error("Failed to copy to clipboard:", err);

      // Fallback method
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      textArea.style.left = "-999999px";
      textArea.style.top = "-999999px";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      try {
        document.execCommand("copy");
        Utils.showSuccessFeedback(button, text);
      } catch (fallbackErr) {
        console.error("Fallback copy failed:", fallbackErr);
      }

      document.body.removeChild(textArea);
    }
  },
};
